from setuptools import setup, find_packages

setup(
    name="Paquete",
    version='1.0',
    description="Distribuido",
    author="Maximiliano Gonzalez",
)